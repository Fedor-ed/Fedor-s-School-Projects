import PySimpleGUI as psg

import qrcode

psg.theme('LightBlue')

layout = [
    [psg.Text('Enter Text: '), psg.InputText()],
    [psg.Button('Create'), psg.Button('Exit')], 
    [psg.Image(key='-IMAGE-', size=(200, 150))]
]

window = psg.Window('QR Code Generator', layout)

while True:
    event, values = window.read()

    if event in (psg.WIN_CLOSED, 'Exit'):
        break

    if event == 'Create':
        data = values[0]
        if data:
            img = qrcode.make(data)
            img.save('qrcode.png')
            window['-IMAGE-'].update(filename='qrcode.png')

window.close()