import 'package:flutter/material.dart';
import 'package:sesmis/pages/home_page.dart';
import 'package:sesmis/pages/dashboard_page.dart';
import 'package:sesmis/pages/registration_form_page.dart';
import 'package:sesmis/pages/login_form_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'School App',
      theme: ThemeData(primarySwatch: Colors.blue, fontFamily: 'Roboto'),
      home: const HomePage(),
      routes: {
        '/dashboard': (context) => const DashboardPage(),
        '/register': (context) => const RegistrationFormPage(),
        '/login': (context) => LoginFormPage(),
      },
    );
  }
}
