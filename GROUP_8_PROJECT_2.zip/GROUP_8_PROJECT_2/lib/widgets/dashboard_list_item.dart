import 'package:flutter/material.dart';

class DashboardListItem extends StatelessWidget {
  final String text;

  const DashboardListItem({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.arrow_right),
      title: Text(text),
    );
  }
}
