import 'package:flutter/material.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        backgroundColor: const Color.fromARGB(255, 81, 68, 228),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Text(
              'Welcome to Your Student Dashboard',
              style: TextStyle(fontSize: 24),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            const Text(
              'Here, you can access important information and manage your student account.',
              style: TextStyle(fontSize: 16),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ListView(
              shrinkWrap: true,
              children: const [
                DashboardListItem(text: 'Register your courses'),
                DashboardListItem(text: 'View your grades'),
                DashboardListItem(text: 'Check your schedule'),
                DashboardListItem(text: 'Access course materials'),
                DashboardListItem(text: 'Submit assignments'),
                DashboardListItem(text: 'Review announcements'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class DashboardListItem extends StatelessWidget {
  final String text;

  const DashboardListItem({super.key, required this.text});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: const Icon(Icons.arrow_right),
      title: Text(text),
    );
  }
}
