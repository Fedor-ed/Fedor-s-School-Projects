import PySimpleGUI as psg
import pyttsx3

engine = pyttsx3.init()

def speak(text):
    if values['-MALE-']:
        voice_id = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech\Voices\Tokens\TTS_MS_EN-US_DAVID_11.0'
    else:
        voice_id = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Speech\Voices\Tokens\TTS_MS_EN-US_ZIRA_11.0'
    engine.setProperty('voice', voice_id)
    engine.say(text)
    engine.runAndWait()

layout = [
    [psg.Text('Enter text:',font=('Arial black', 13))],
    [psg.InputText(key='input',font=('Arial black', 13)), psg.Button('Speak',font=('Arial black', 13), key='speak')],
    [psg.Text('Select a Voice:',font=('Arial black', 13)), psg.Radio('Male', "RADIO1", default=True, key='-MALE-',font=('Arial black', 13)), psg.Radio('Female', "RADIO1", key='-FEMALE-',font=('Arial black', 13))],
    [psg.Button('Exit',font=('Arial black', 13))]
]

window = psg.Window('Text-to-Speech App', layout)

while True:
    event, values = window.read()
    if event in (psg.WINDOW_CLOSED, 'Exit'):
        break
    if event == 'speak':
        text = values['input']
        speak(text)

window.close(), 'Exit'):


        break


    


    if event == 'speak':


        text = values['input']


        speak(text)





window.close()


