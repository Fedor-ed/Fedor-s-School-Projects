# School of Engineering Web Application

This is a web application for the School of Engineering, built using React and CSS. It provides features for student registration, login, and a dashboard for managing student accounts and accessing important information.

## Features

- **Homepage:** The homepage welcomes users to the School of Engineering and provides links to register, login, and access the student dashboard.

- **Registration:** Students can register by providing their student ID, name, email, and password.

- **Login:** Students can log in using their student ID and PIN.

- **Dashboard:** The dashboard provides students with access to important information and features, including viewing grades, checking schedules, accessing course materials, submitting assignments, and reviewing announcements.

## Installation

1. Clone the repository: `git clone [https://github.com/Fedor009/Fedor-s-School-Projects.git]`
2. Install dependencies: `npm install`
3. Start the development server: `npm start`

Make sure you have Node.js and npm installed on your system.

## Technologies Used

- React
- React Router
- CSS

## Usage

- Access the application by navigating to the provided URL or running it locally on your machine.
- Register as a student using the registration form.
- Log in with your student ID and PIN.
- Explore the student dashboard to access various features and information.

## Contributing

Contributions are welcome! If you find any issues or have suggestions for improvements, please open an issue or submit a pull request.


## Contact

For any inquiries or feedback, please contact the project maintainer:

- Fiador Kelvin
- Email: fiadorkelvin9@gmail.com

