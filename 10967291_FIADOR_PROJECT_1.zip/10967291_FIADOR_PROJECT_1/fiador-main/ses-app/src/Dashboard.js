import React from 'react';
import Navigation from './Navigation';
import './Dashboard.css'; // Import the CSS file for styling

function Dashboard() {
  return (
    <div>
      <Navigation />
      <div className="dashboard">
        <h2 className="dashboard-title">Welcome to Your Student Dashboard</h2>
        <p className="dashboard-description">
          Here, you can access important information and manage your student account.
        </p>
        <ul className="dashboard-list">
          <li className="dashboard-list-item">View your grades</li>
          <li className="dashboard-list-item">Check your schedule</li>
          <li className="dashboard-list-item">Access course materials</li>
          <li className="dashboard-list-item">Submit assignments</li>
          <li className="dashboard-list-item">Review announcements</li>
        </ul>
      </div>
    </div>
  );
}

export default Dashboard;
