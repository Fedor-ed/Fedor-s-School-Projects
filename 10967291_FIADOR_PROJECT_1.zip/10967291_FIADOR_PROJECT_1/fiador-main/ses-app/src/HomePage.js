import React from 'react';
import { Link } from 'react-router-dom';
import Navigation from './Navigation';
import './HomePage.css'; // Import the CSS file for styling

export default function HomePage() {
  return (
    <div>
      <Navigation />

      <div className="homepage">
        <h1 className="homepage-title">School of Engineering Science</h1>
        <p className="homepage-description">Welcome to the School of Engineering</p>

        <div className="homepage-links">
          <Link to="/dashboard" className="homepage-link">
            Go to Dashboard
          </Link>
          <Link to="/register" className="homepage-link">
            Register
          </Link>
          <Link to="/login" className="homepage-link">
            Login 
          </Link>
        </div>
      </div>
    </div>
  );
}
