import React, { useState } from 'react';
import Navigation from './Navigation';
import './RegistrationForm.css'; // Import the CSS file for styling

export default function RegistrationForm() {
  const [studentID, setStudentID] = useState('');
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    if (studentID.trim() === '') {
      setError('Please enter your Student ID.');
      return;
    }
    if (name.trim() === '') {
      setError('Please enter your Name.');
      return;
    }
    if (email.trim() === '') {
      setError('Please enter your Email.');
      return;
    }
    if (password.trim() === '') {
      setError('Please enter your Password.');
      return;
    }

    // Perform registration logic here

    // Clear form fields
    setStudentID('');
    setName('');
    setEmail('');
    setPassword('');
    setError('');
  };

  return (
    <div>
      <Navigation />

      <div className="registration-form">
        <form onSubmit={handleSubmit}>
          <h2 className="registration-form-title">Student Registration</h2>
          <label className="registration-form-label">
            Student ID:
            <input
              type="text"
              value={studentID}
              onChange={(e) => setStudentID(e.target.value)}
              className="registration-form-input"
            />
          </label>

          <label className="registration-form-label">
            Name:
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="registration-form-input"
            />
          </label>

          <label className="registration-form-label">
            Email:
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="registration-form-input"
            />
          </label>

          <label className="registration-form-label">
            Password:
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="registration-form-input"
            />
          </label>

          <button type="submit" className="registration-form-button">Register</button>
        </form>

        {error && <p className="error-message">{error}</p>}
      </div>
    </div>
  );
}
