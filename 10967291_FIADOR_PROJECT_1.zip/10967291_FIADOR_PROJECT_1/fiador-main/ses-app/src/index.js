import React from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Routes, Route } from 'react-router-dom';




import Homepage from './HomePage';
import LoginForm from './LoginForm';
import RegistrationForm from './RegistrationForm';
import Navigation from './Navigation';
import Dashboard from './Dashboard';


function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Homepage />} />
        <Route path="/login" element={<LoginForm />} />
        <Route path="/register" element={<RegistrationForm />} />
        
        <Route path="/navigation" element={<Navigation />} />
        <Route path="/dashboard" element={<Dashboard />} />
      </Routes>
    
    </BrowserRouter>
  );
}
ReactDOM.render(<App />, document.getElementById('root'));
