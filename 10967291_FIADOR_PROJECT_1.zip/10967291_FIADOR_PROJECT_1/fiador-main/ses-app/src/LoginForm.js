import React, { useState } from 'react';
import Navigation from './Navigation';
import './LoginForm.css'; // Import the CSS file for styling

export default function LoginForm() {
  const [studentID, setStudentID] = useState('');
  const [pin, setPin] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();

    if (studentID.trim() === '') {
      setError('Please enter your Student ID.');
      return;
    }
    if (pin.trim() === '') {
      setError('Please enter a valid PIN.');
      return;
    }

    // Perform login logic here

    // Clear form fields
    setStudentID('');
    setPin('');
    setError('');
  };

  return (
    <div>
      <Navigation />

      <div className="login-form">
        <form onSubmit={handleSubmit}>
          <h2 className="login-form-title">Student Login</h2>
          <label className="login-form-label">
            Student ID:
            <input
              type="text"
              value={studentID}
              onChange={(e) => setStudentID(e.target.value)}
              className="login-form-input"
            />
          </label>

          <label className="login-form-label">
            PIN:
            <input
              type="password"
              value={pin}
              onChange={(e) => setPin(e.target.value)}
              className="login-form-input"
            />
          </label>

          <button type="submit" className="login-form-button">Login</button>
        </form>

        {error && <p className="error-message">{error}</p>}
      </div>
    </div>
  );
}
